from typing import Dict, List
import json

# Optional ChromaDB import
try:
    import chromadb
    from chromadb.config import Settings
    CHROMADB_AVAILABLE = True
except (ImportError, Exception) as e:
    CHROMADB_AVAILABLE = False
    chromadb = None
    Settings = None
    print(f"Warning: ChromaDB not available: {e}")


class VectorSearchService:
    """Service for vector similarity search using ChromaDB"""
    
    def __init__(self):
        self.client = None
        self.collection = None
        self.collection_name = "cash_buyers"
        
        if CHROMADB_AVAILABLE:
            try:
                self.client = chromadb.Client(Settings(
                    chroma_db_impl="duckdb+parquet",
                    persist_directory="./chroma_db"
                ))
                self.collection = self._get_or_create_collection()
            except Exception as e:
                print(f"Warning: Could not initialize ChromaDB: {e}")
                self.client = None
                self.collection = None
    
    def _get_or_create_collection(self):
        """Get or create the cash buyers collection"""
        if not self.client:
            return None
        try:
            return self.client.get_collection(name=self.collection_name)
        except Exception:
            return self.client.create_collection(name=self.collection_name)
    
    async def generate_embedding(self, buyer_data: Dict) -> List[float]:
        """Generate embedding vector for buyer data"""
        # Combine text features for a more descriptive embedding
        text_features = (
            f"Name: {buyer_data.get('name', '')}. "
            f"Company: {buyer_data.get('company_name', '')}. "
            f"Location: {buyer_data.get('city', '')}, {buyer_data.get('state', '')}. "
            f"Property Types: {', '.join(buyer_data.get('preferred_property_types', []))}. "
            f"Price Range: {buyer_data.get('price_range_min', 0)} to {buyer_data.get('price_range_max', 0)}."
        )
        
        # Use OpenAI for embeddings if available
        import os
        from openai import OpenAI
        api_key = os.getenv("OPENAI_API_KEY")
        if api_key:
            try:
                client = OpenAI(api_key=api_key)
                response = client.embeddings.create(
                    input=text_features,
                    model="text-embedding-3-small"
                )
                return response.data[0].embedding
            except Exception as e:
                print(f"Warning: OpenAI embedding failed: {e}")
        
        # Fallback: Simple deterministic vector based on text features
        # This is still a placeholder but slightly more robust than before
        import hashlib
        hash_obj = hashlib.sha256(text_features.encode())
        hash_hex = hash_obj.hexdigest()
        # Create a 384-dim vector from the hash
        embedding = []
        for i in range(384):
            val = int(hash_hex[i % 64], 16) / 15.0
            embedding.append(val)
        
        return embedding
    
    async def add_buyer(self, buyer_id: str, buyer_data: Dict, embedding: List[float]):
        """Add buyer to vector database"""
        if not self.collection:
            return  # Skip if ChromaDB not available
        
        metadata = {
            "name": buyer_data.get("name"),
            "city": buyer_data.get("city", ""),
            "state": buyer_data.get("state", ""),
            "preferred_types": json.dumps(buyer_data.get("preferred_property_types", [])),
            "price_min": str(buyer_data.get("price_range_min", 0)),
            "price_max": str(buyer_data.get("price_range_max", 0))
        }
        
        try:
            self.collection.add(
                ids=[str(buyer_id)],
                embeddings=[embedding],
                metadatas=[metadata]
            )
        except Exception as e:
            print(f"Warning: Could not add buyer to ChromaDB: {e}")
    
    async def search_similar_buyers(self, criteria: Dict, limit: int = 10) -> List[Dict]:
        """Search for similar cash buyers based on criteria"""
        if not self.collection:
            return []  # Return empty if ChromaDB not available
        
        try:
            # Generate query embedding
            query_embedding = await self.generate_embedding(criteria)
            
            # Search
            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=limit
            )
            
            # Format results
            similar_buyers = []
            if results['ids'] and len(results['ids'][0]) > 0:
                for i, buyer_id in enumerate(results['ids'][0]):
                    similar_buyers.append({
                        "buyer_id": buyer_id,
                        "metadata": results['metadatas'][0][i],
                        "distance": results['distances'][0][i] if 'distances' in results else None
                    })
            
            return similar_buyers
        except Exception as e:
            print(f"Warning: Could not search ChromaDB: {e}")
            return []

